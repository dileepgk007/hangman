'use strict'
class HangMan {
    constructor(word, remainingGuess) {
            this.word = word.toLowerCase().split(''),
            this.remainingGuess = remainingGuess,
            this.guessedLetter = [],
            this.status = 'PLAYING'
    }

    getPuzzele() {
        let puzzle = ''
        this.word.forEach((letter) => {
            if (this.guessedLetter.includes(letter) || letter === ' ') {

                puzzle = puzzle + letter

            }
            else {
                puzzle += '*'
            }
        })
        return puzzle
    }
//this is just a replacement of above function
  get  gPuzzele() {
        let puzzle = ''
        this.word.forEach((letter) => {
            if (this.guessedLetter.includes(letter) || letter === ' ') {

                puzzle = puzzle + letter

            }
            else {
                puzzle += '*'
            }
        })
        return puzzle
    }

    setSTatus() {

             const finished = this.word.every((letter)=>{
                return this.guessedLetter.includes(letter)|| letter === ' '
            })   

        /*    const unGuessedLetter= this.word.filter((letter)=>{
               return !this.guessedLetter.includes(letter)
           })
       
           const finished = unGuessedLetter.length=== 0  */

//This has some issue 
/*          let finished 
        this.word.forEach((letter) => {
            if (this.guessedLetter.includes(letter)) {
                finished = true
            }
            else {
                finished = false
            }
        })   */

        if (this.remainingGuess === 0) {
            this.status = 'FAILED'

        }

        else if (finished === true) {
            this.status = 'CORRECT WORD'
        }

        else {
            this.status = 'PLAYING'
        }


    }

    displayMessage() {

        let message = ''
        if (this.status === 'PLAYING') {

            message = `${this.status}. Remaining guess is ${this.remainingGuess}`

        }

        else if (this.status === 'FAILED') {
            message = `${this.status}.Nice Try.  The word was ${this.word.join('')}`
        }

        else {
            message = `${this.status}.CONGRATULATIONS!`

        }
        return message

    }
//this is just a replacement of above function
    get finalMessage(){
        let message = ''
        if (this.status === 'PLAYING') {

            message = `${this.status}. Remaining guess is ${this.remainingGuess}`

        }

        else if (this.status === 'FAILED') {
            message = `${this.status}.Nice Try.  The word was ${this.word.join('')}`
        }

        else {
            message = `${this.status}.CONGRATULATIONS!`

        }
        return message

    }

    guessWord(letterGuessed) {
        letterGuessed = letterGuessed.toLowerCase()
        const isUnique = !this.guessedLetter.includes(letterGuessed)// if we enter a letter that is already in array, it will be true, but went want not in array that we will push to array
        const isBadGuess = !this.word.includes(letterGuessed)//if enter a letter that is  match with WORD,IT WILL BE TRUE, but we want not in matching

        if (this.status != 'PLAYING') {
            return this.status
        }

        if (isUnique) {
            this.guessedLetter.push(letterGuessed)
        }
        if (isUnique && isBadGuess) {

            this.remainingGuess--
        }

        this.setSTatus()
    }



}


export {HangMan as default}
