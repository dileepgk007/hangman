import uuidv4 from 'uuid/v4'
import validator from 'validator';
import HangMan from './hangman'
import asyncPuzzle1 from './request'

console.log(uuidv4())

//var validator = require('validator');

console.log(validator.isEmail('foo@bar.com'))
console.log(validator.isEmail('foo@bar'))


const puzzleEl = document.querySelector('#puzzle')
const guessEl = document.querySelector('#guess')
const statusEl = document.querySelector('#status')
const answerEl = document.querySelector('#puzzle1')
let game1


window.addEventListener('keypress', (e) => {

  const letterGuessed = String.fromCharCode(e.charCode)
  game1.guessWord(letterGuessed)

  render()
})



/*  const render = ()=>{
  
statusEl.textContent = `${game1.status}`
  puzzeleEl.textContent = game1.gPuzzele.toUpperCase()//using getter here to replacde above line
  guessEl.textContent = game1.remainingGuess
  statusEl.textContent = `${game1.finalMessage}`//using getter here to replacde above line
} */
 
const render = () => {

  puzzleEl.innerHTML = ''
  guessEl.textContent = game1.remainingGuess
  statusEl.textContent = `${game1.status}`
  game1.gPuzzele.toUpperCase().split('').forEach(function (letters) {
    const letterEl = document.createElement('span')
    letterEl.textContent = letters
    puzzleEl.appendChild(letterEl)
    statusEl.textContent = `${game1.finalMessage}`
  })

} 

const startGame = async () => {
  const puzzle = await asyncPuzzle1('2')

  //This is how if we want to get the puzzel from data object

  /*   const puzzle = await asyncPuzzle('3').then(function(data){
      return data.puzzle
    }) */
  game1 = new HangMan(puzzle, 4)
  answerEl.textContent = puzzle
  render()
}

/* document.querySelector('#Reset').addEventListener('click',function(){
  startGame()  
})
startGame() */

document.querySelector('#Reset').addEventListener('click', startGame)

startGame()

