//

const getPuzzle = (wordCount, callback) => {
  const request = new XMLHttpRequest()
  request.addEventListener('readystatechange', (e) => {
    if (e.target.readyState === 4 && e.target.status === 200) {
      const data = JSON.parse(e.target.responseText)
      callback(undefined, data.puzzle)
    }
    else if (e.target.readyState === 4) {
      callback('Error happened. Wrong url', undefined)
      //  console.log('Error happened. Wrong url')
    }

  })
  // request.open('GET', `//puzzle.mead.io/puzzle?wordCount=2`)
  request.open('GET', `//puzzle.mead.io/puzzle?wordCount=${wordCount}`)
  request.send()

}

const getDetails = (countryCode, callback) => {

  const cRequest = new XMLHttpRequest()

  cRequest.addEventListener('readystatechange', (e) => {
    if (e.target.readyState === 4 && e.target.status === 200) {

      const data = JSON.parse(e.target.responseText)
      // console.log(data)
      const cnty = data.find((country) => {
        return country.alpha2Code === countryCode
      })

      // console.log(cnty.name)
      //callback(undefined, cnty.name)//will get the name. we can define it where we are using the same. use below line for better
      callback(undefined, cnty)//will get the  colplete details


    }

    else if (e.target.readyState === 4) {
      callback('Error happened. Wrong url', undefined)
    }

  })

  cRequest.open('GET', '//restcountries.eu/rest/v2/all')
  cRequest.send()

}

const prPuzzle = (wordCount) => new Promise((resolve, reject) => {

  const request = new XMLHttpRequest()
  request.addEventListener('readystatechange', (e) => {
    if (e.target.readyState === 4 && e.target.status === 200) {
      const data = JSON.parse(e.target.responseText)
      resolve(`calling from Promise- Word is ${data.puzzle}`)
    }
    else if (e.target.readyState === 4) {
      reject('Error happened using Promise. Wrong url')
      //  console.log('Error happened. Wrong url')
    }

  })

  request.open('GET', `//puzzle.mead.io/puzzle?wordCount=${wordCount}`)
  request.send()

})







const prPuzzle1 = function(count){
  return new Promise((resolve,reject)=>{

    const request = new XMLHttpRequest()
  request.addEventListener('readystatechange', (e) => {
    if (e.target.readyState === 4 && e.target.status === 200) {
      const data = JSON.parse(e.target.responseText)
      resolve(data.puzzle)
    }
    else if (e.target.readyState === 4) {
      reject('Error happened. Wrong url')
     //  console.log('Error happened. Wrong url')
    }

  })
  
  request.open('GET', `//puzzle.mead.io/puzzle?wordCount=${count}`)
  request.send()
    

  })
} 


const prCounty = (cCode) => {
  return new Promise(function (resolve, reject) {
    const cRequest1 = new XMLHttpRequest()
    cRequest1.addEventListener('readystatechange', (e) => {
      if (e.target.readyState === 4 && e.target.status === 200) {

        const data = JSON.parse(e.target.responseText)
        // console.log(data)
        const cnty = data.find((country) => {
          return country.alpha2Code === cCode
        })
        resolve(cnty)


      }

      else if (e.target.readyState === 4) {
        reject('Error happened. Wrong url')
      }

    })

    cRequest1.open('GET', '//restcountries.eu/rest/v2/all')
    cRequest1.send()



  })
}

const fecthGetPuzzle = (wordCount) => {

  return fetch(`//puzzle.mead.io/puzzle?wordCount=${wordCount}`, {}).then((response) => {

    if (response.status === 200) {
      return response.json()
    }
    else {
      throw new Error(`Fetch API is throwing error`)
    }

  }).then((data) => {
    return data.puzzle//we can also remove this then loop and declare data.puzzle directly in app.js
  })

}

const fetchGetCountry = (countryCode) => {


  return fetch('//restcountries.eu/rest/v2/all').then(function (response) {
    if (response.status === 200) {
      return response.json()


    }
    else {
      throw new Error(`etch API is throwing error`)
    }
  }).then((data) => {
    const cnty = data.find((cnty) => {
      return cnty.alpha2Code === countryCode
    })
    return cnty
  })/* .then(function (cnty) {
    return cnty.name

  }) */

}

//here we are using another api
const getLocationAPI = ()=>{

 return fetch(`//ipinfo.io/json?ef87dab6f7d3e`).then((response)=>{

  if (response.status ===200){
    
    return response.json()
  }

  else{
    throw new Error('Location API is not working')
  }
  })/* .then(function(location){
    return location.region
  }) */

}

//Async Await


const asyncPuzzle = async function(wordCount){

  const response =await fetch(`//puzzle.mead.io/puzzle?wordCount=${wordCount}`)
  if(response.status===200){
   /*  let data = response.json()
    return data */

    return response.json()
  

  }
  else{
    throw new Error('Async Await Failed')
  }


}

const asyncPuzzle1 = async function(wordCount){

  const response = await fetch(`//puzzle.mead.io/puzzle?wordCount=${wordCount}`)
  if(response.status===200){
    let data = await response.json()
  
    return data.puzzle

  }
  else{
    throw new Error('Async Await Failed')
  }


}

 
const asyncCountry = async function(cCode){
  const response = await fetch('//restcountries.eu/rest/v2/all')
  if(response.status===200){
    const data = await response.json()
    return data.find((country)=>
    { return country.alpha2Code === cCode
    })
    
  
    
  }
  else{
    throw new Error('asyncCountry is not workig')
  }
  
}

const asyncLocation = async function(){

  const response = await fetch(`//ipinfo.io/json?ef87dab6f7d3e`)
  if(response.status=== 200){
    const location = response.json()
    return location
  }

}
//here we are calling chain asynd fuction
const getCurrentCounty = async function(){

  const location = await asyncLocation()
  const country = await asyncCountry(location.country)
  return country

}


export {asyncPuzzle1 as default}